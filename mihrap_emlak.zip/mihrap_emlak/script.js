
var propertiesData = [
    { 
        title: "Modern Daire", 
        location: "İstanbul", 
        price: "$250,000", 
        image: "modern daire2.png" 
    },
    { 
        title: "Deniz Manzaralı Villa", 
        location: "Antalya", 
        price: "$5,000", 
        image: "deniz manzaralı1.png" 
    },
    { 
        title: "Şehir Merkezi Ofis", 
        location: "Ankara", 
        price: "$150,000", 
        image: "şehir merkezi Ofis.png" 
    },
    { 
        title: "Bahçeli Müstakil Ev", 
        location: "İzmir", 
        price: "$350,000", 
        image: "müstakil ev1.png" 
    }
];

// Emlakları listeleme fonksiyonu
function listProperties() {
    var propertiesList = document.getElementById("properties-list");
    propertiesData.forEach(function(property) {
        var propertyItem = document.createElement("li");
        propertyItem.innerHTML = `
            <div class="property">
                <img src="${property.image}" alt="${property.title}">
                <h3>${property.title}</h3>
                <p>${property.location}</p>
                <p>${property.price}</p>
            </div>
        `;
        // propertiesList.appendChild(propertyItem);
    });
}

// İletişim formunu işleme fonksiyonu
function processForm() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;

    // Burada form verilerini işleme kodu eklenebilir (örneğin, sunucuya gönderme)

    // İşlem başarılı olduğunda kullanıcıya alert göster
    alert("Mesajınız başarıyla gönderildi! Teşekkür ederiz.");
}

// Sayfa yüklendiğinde emlakları listele
window.onload = listProperties;


// JavaScript (script.js)

// Resimlerin bulunduğu bir dizi oluştur
var images = [
    { src: "resimler/modern daire2.png", caption: "İstanbulda Modern Bir Daire Almaya Ne Dersin..." },
    { src: "resimler/deniz manzaralı1.png", caption: "Antalyada Deniz Manzaralı Eve Ne Dersin..." },
    { src: "resimler/şehir merkezi Ofis.png", caption: "Ankarada Şehir Merkezinde Ofis..." },
    { src: "resimler/müstakil ev1.png", caption: "İzmirde Müstakil Bir Daire..." }
];

// Galeri div'ini seç
var gallery = document.getElementById("gallery");

// Her bir resim için bir olay dinleyici ekle
gallery.addEventListener("click", function() {
    // İlk resmi al
    var currentImage = this.querySelector(".gallery-image");
    // Şu anki resmin kaynağını al
    var currentSrc = currentImage.getAttribute("src");
    // Kaynağın dizideki index'ini bul
    var currentIndex = images.findIndex(function(image) {
        return image.src === currentSrc;
    });
    // Bir sonraki resmin index'ini hesapla
    var nextIndex = (currentIndex + 1) % images.length;
    // Yeni resmin kaynağını ve alt metnini ayarla
    currentImage.setAttribute("src", images[nextIndex].src);
    currentImage.nextElementSibling.textContent = images[nextIndex].caption;
});

$(document).ready(function(){
    // Bir sonraki resme geçiş
    $(".carousel-control-next").click(function(){
        $(".carousel").carousel("next");
    });
    
    // Bir önceki resme geçiş
    $(".carousel-control-prev").click(function(){
        $(".carousel").carousel("prev");
    });
});

// JSON dosyasını oku
fetch('contacts.json')
  .then(response => response.json())
  .then(data => {
    // Verileri işle
    data.forEach(contact => {
      // Her bir kişi için gerekli işlemleri yap
      console.log(contact.name); // Örneğin, konsola adları yazdır
    });
  })
  .catch(error => {
    console.error('Hata:', error);
  });

 